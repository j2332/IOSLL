import SwiftUI

struct Account: Equatable {

    let firstname: String
    let lastname: String
    let preferredname: String
    let gradyear: String
    let email: String
    
   
}
