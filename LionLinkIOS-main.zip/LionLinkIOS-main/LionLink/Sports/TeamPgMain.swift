import SwiftUI

struct TeamPgMain: View {
    var body: some View {
        Text("Hello, Team!")
    }
}
